Put your licensed font files here:
  SloopScript.woff2
  NewIcon-Light.woff2
  NewIcon-Regular.woff2
(the @font-face block at the top of index.html already points to these names)
