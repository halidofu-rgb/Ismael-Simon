/* ==========================================================================
   EDITABLE ILLUSTRATIONS
   --------------------------------------------------------------------------
   One entry per drawing. Each value is either
     • the path of an .svg file in assets/illustrations/   (recommended), or
     • any image URL (png / jpg / webp).
   To replace a drawing: save your file over the one in assets/illustrations/
   (same name), or change the path below. Layout code never needs touching.
   Champagne line-art on a transparent background works best (colour #e9d7ab).
   ========================================================================== */
const illustrations = {
  chandelier: "assets/illustrations/chandelier.svg",// opening screen — hangs from the top
  dinnerTable: "assets/illustrations/dinner-table.svg",// opening screen — bottom centre
  manor: "assets/illustrations/manor.png",          // section 02, The Manoir
  ceremony: "assets/illustrations/ceremony.svg",    // timeline 15:00 — mairie
  honeymoon: "assets/illustrations/honeymoon.svg",   // section 07, Our Honeymoon
  giftAccent: "assets/illustrations/gift-accent.svg", // section 07, flanks the IBAN (mirrored on the right)
  cocktail: "assets/illustrations/cocktail.svg",    // timeline 17:00 — coupes
  dinner: "assets/illustrations/dinner.svg",        // timeline 20:00 — table setting
  party: "assets/illustrations/party-mirror-ball.svg",// timeline 23:00 — mirror ball
  suit: "assets/illustrations/suit.svg",            // dress code — gentlemen
  eveningDress: "assets/illustrations/evening-dress.svg",// dress code — ladies
};
