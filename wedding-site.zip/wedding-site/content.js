/* ==========================================================================
   EDITABLE WEDDING CONTENT
   --------------------------------------------------------------------------
   Every word guests read lives in this file. Change the text between the
   quotation marks; never change the names on the left of each colon.
     • a line break inside a text is written  \n   (e.g. "Manoir de\nTourville")
     • to hide a button, empty its link in EDITABLE LINKS (further below)
   Illustrations are in illustrations.js — links are at the bottom of this file.
   ========================================================================== */
const weddingContent = {

  pageTitle: "Ismael & Simon — Save the Date",

  /* ---------- NAMES ---------- */
  names: { first: "ISMAEL", joiner: "&", second: "SIMON" },

  /* ---------- OPENING SCREEN ---------- */
  hero: {
    dear: "Dear,",
    lookForward: "We look forward to\ncelebrating with you.",
    dinnerOf: "Wedding Celebration of",
    weekday: "Saturday,",
    dateLines: "15th May 2027\n7:00 pm",
    atWord: "At",
    venueLines: "Manoir de\nTourville",
    place: "Les Halles (69)"
  },

  /* ---------- DATE, TIME, CALENDAR BUTTON ---------- */
  event: {
    startISO: "2027-05-15T19:00:00",            // used for the countdown
    calStart: "20270515T190000",                // Google Calendar start (YYYYMMDDTHHMMSS)
    calEnd:   "20270516T010000",                // Google Calendar end
    calTitle: "Wedding Dinner of Ismael & Simon",
    calLocation: "Manoir de Tourville, 196 chemin de Tourville, 69610 Les Halles, France",
    timezone: "Europe/Paris",
    calendarButton: "Add to your calendar"
  },

  /* ---------- SECTION TITLES (the numbering is free text) ---------- */
  labels: {
    date: "01 — The Date", manoir: "02 — The Manoir", evening: "03 — The Evening",
    celebration: "04 — The Celebration", dress: "05 — Dress code", stay: "06 — Where to stay",
    gift: "07 — A Gift", info: "08 — Information", rsvp: "09 — RSVP"
  },

  /* ---------- 01 THE DATE ---------- */
  date: {
    day: "15", month: "May", year: "2027",
    text: "Saturday,\nat seven in the evening.",
    countdown: "{d} days, {h} hours, {m} minutes to go"  // "" hides it
  },

  /* ---------- 02 THE MANOIR + ADDRESS ---------- */
  manoir: {
    title: "Manoir de Tourville",
    text: "An old house in the Rhône, lit for one night only. Stone, gravel, tall windows, and a table long enough for everyone we love."
  },
  location: {
    addressLines: "196 chemin de Tourville\n69610 Les Halles\nFrance",
    button: "Open in Google Maps"               // link: links.googleMaps
  },

  /* ---------- 03 THE EVENING ---------- */
  evening: {
    l1: "A long table.", l2: "Candlelight.", l3: "Everyone we love.",
    text: "Dinner is served at seven. The night will run late."
  },

  /* ---------- 04 THE CELEBRATION — TIMELINE ----------
     ADD an event: copy one { … } line, paste it where you want it, edit it.
     REMOVE an event: delete its line.
     illustration: a name from illustrations.js ("" = no drawing).
     highlight: true  fills the time in solid gold. */
  timeline: {
    title: "The Celebration",
    note: "Preliminary timings — the final schedule will follow.",
    items: [
      { time: "15:00", title: "Civil ceremony",           note: "Mairie de Saint Cyr de Favi\u00e8res", illustration: "ceremony" },
      { time: "17:00", title: "Cocktail & Vin d'Honneur", note: "Manoir de Tourville",             illustration: "cocktail" },
      { time: "19:00", title: "Wedding Dinner",           note: "Manoir de Tourville",             illustration: "dinner", highlight: true },
      { time: "22:00", title: "Party",                    note: "Manoir de Tourville",             illustration: "party" }
    ]
  },

  /* ---------- 05 DRESS CODE ---------- */
  dress: {
    title: "Formal",
    menLabel: "For gentlemen",  menText: "Suit & tie",                    menIllustration: "suit",
    womenLabel: "For ladies",   womenText: "Long dresses / evening gowns", womenIllustration: "eveningDress",
    colors: [                                   // hex = the swatch colour
      { name: "Navy blue",   hex: "#0a1a55" },
      { name: "Olive green", hex: "#6b6a2b" },
      { name: "Burgundy",    hex: "#6b1730" }
    ]
  },

  /* ---------- 06 WHERE TO STAY ----------
     ADD a place: copy one { … } block in "nearby", then add a matching line
     (e.g. accommodation5) in EDITABLE LINKS below and use that name in "link".
     REMOVE a place: delete its { … } block.
     distance is optional (e.g. "12 min by car") — leave "" to hide it. */
  stay: {
    title: "Where to stay",
    intro: "Rooms are available at the Manoir itself, and a few good addresses lie nearby.",
    onsiteLabel: "On site",
    onsite: {
      name: "Manoir de Tourville",
      text: "Guest rooms, including a suite in the tower, for approximately 15 guests.",
      button: "Stay at the Manoir"              // link: links.manoirAccommodation
    },
    viewLocation: "View location",              // link: links.googleMaps
    nearbyLabel: "Nearby accommodation",
    visitButton: "Visit website",
    nearby: [
      { name: "Château de Chambost", location: "Chambost-Longessaigne", distance: "", link: "accommodation1",
        text: "A 17th-century family château on a working farm, with period-decorated guest rooms and breakfast included." },
      { name: "Gîte Maison de Famille", location: "Les Halles", distance: "", link: "accommodation2",
        text: "A large village house with a walled garden and six bedrooms, for up to 15 friends travelling together." },
      { name: "Gîte La Clef des Champs", location: "Les Halles", distance: "", link: "accommodation3",
        text: "A four-bedroom country house for up to 11 guests, set in the countryside beside the village." },
      { name: "La Ferme du Château", location: "Chambost-Longessaigne", distance: "", link: "accommodation4",
        text: "An independent stone farmhouse gîte on a dairy farm, with a shared pool in summer." }
    ]
  },

  /* ---------- 07 A GIFT ----------
     A gentle, optional suggestion in place of a gift registry — never phrased as an obligation. */
  gift: {
    title: "A Wish, Should You Like",
    text: "Your presence is truly the only gift we ask for. Should you wish to mark the day further, a contribution toward our honeymoon would move us deeply.",
    bankLabel: "IBAN",
    iban: "FR76 2823 3000 0163 9580 0816 072"
  },

  /* ---------- 07 INFORMATION ---------- */
  info: [
    { label: "When",       value: "Saturday 15 May 2027 — dinner at 7:00 pm" },
    { label: "Where",      value: "Manoir de Tourville, Les Halles (69), France" },
    { label: "Invitation", value: "Formal invitation to follow" }
  ],

  /* ---------- 08 RSVP ----------
     If links.rsvp is filled, a button opens it. Otherwise (or in addition,
     when showForm is true) the form below opens an email to "email". */
  rsvp: {
    script: "Répondez,", title: "RSVP",
    text: "We can't wait to celebrate with you.",
    button: "RSVP",
    email: "", showForm: true,
    form: { name: "Your name", reply: "Your reply", yes: "With joy", no: "With regret",
            note: "A word for us (optional)", submit: "Send our reply",
            errName: "Please tell us your name.", soon: "Replies open soon — thank you.",
            sent: "Your email is ready to send. Thank you." }
  },

  /* ---------- CLOSING ---------- */
  closing: { script: "À bientôt,", names: "ISMAEL & SIMON", small: "Save the date — 15 May 2027. Formal invitation to follow." }
};

/* ==========================================================================
   EDITABLE LINKS
   --------------------------------------------------------------------------
   Replace a URL between the quotation marks. An empty "" hides that button.
   ========================================================================== */
const links = {
  rsvp: "",                                                                   // your RSVP form / page
  googleMaps: "https://www.google.com/maps/search/?api=1&query=Manoir+de+Tourville+196+chemin+de+Tourville+69610+Les+Halles+France",
  manoirAccommodation: "https://www.manoirdetourville.com/nos-chambres-d-hotes/",
  accommodation1: "https://www.chateaudechambost.com/",
  accommodation2: "https://www.gites-de-france-rhone.com/fiche-hebergement-3079.html",
  accommodation3: "https://www.montsdulyonnaistourisme.fr/hebergement-locatif/gite-la-clef-des-champs-les-halles/",
  accommodation4: "https://www.gites-de-france.com/fr/auvergne-rhone-alpes/rhone/la-ferme-du-chateau-69g1484"
};
